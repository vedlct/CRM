<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Possibilitychange extends Model
{
    public $timestamps = false;
}
