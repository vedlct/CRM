<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Callingreport extends Model
{
    //
}
