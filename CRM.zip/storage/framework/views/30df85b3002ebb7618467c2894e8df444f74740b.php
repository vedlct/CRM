<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Update country</div>
                <div class="panel-body">
                    <form class="form-horizontal" role="form" method="POST" action="<?php echo e(route('country.update', ['id' => $country->countryId])); ?>">
                        <input type="hidden" name="_method" value="PATCH">
                        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                        <div class="form-group<?php echo e($errors->has('countryName') ? ' has-error' : ''); ?>">
                            <label for="countryName" class="col-md-4 control-label">Country Name</label>

                            <div class="col-md-6">
                                <input id="countryName" type="text" class="form-control" name="countryName" value="<?php echo e($country->countryName); ?>" required autofocus>

                                <?php if($errors->has('countryName')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('countryName')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="col-md-6 col-md-offset-4">
                                <button type="submit" class="btn btn-primary">
                                    Update
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>