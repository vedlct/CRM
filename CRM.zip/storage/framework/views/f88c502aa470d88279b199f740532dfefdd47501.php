<?php $__env->startSection('content'); ?>

    <div class="card" style="padding: 30px;">
        <div class="card-body">
    <button type="button" class="btn btn-info" data-toggle="collapse" data-target="#demo">Todays Call List</button>
    <div id="demo" class="collapse">
        <table class="table table-hover" style="max-width: 1000px;">
            <thead>
            <tr>
                <th>First Name</th>
                <th>Last Name</th>
                <th>Email</th>
                <th>User Type</th>
                <th>Called</th>

            </tr>
            </thead>
            <tbody>

            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                <td><?php echo e($user->firstName); ?></td>
                <td><?php echo e($user->lastName); ?></td>
                <td><?php echo e($user->userEmail); ?></td>
                    <td><?php echo e($user->userType->typeName); ?></td>
                <td><?php echo e($user->total); ?></td>

            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>


    </div>
        </div></div>




<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>