<?php $__env->startSection('header'); ?>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jquery-confirm/3.3.0/jquery-confirm.min.css">
    <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>





    <div class="card" style="padding:10px;">
        <div class="card-body">
            <h2 class="card-title" align="center"><b>Assign Lead To User</b></h2>



            <div class="table-responsive m-t-40">
                <table id="myTable" class="table table-bordered table-striped">
                    <thead>
                    <tr>

                        <th>Select</th>
                        <th>Company Name</th>
                        <th>Category</th>
                        <th>Website</th>
                        <th>Email</th>
                        <th>Country</th>
                        <th>Comments</th>
                        <th>Mined By</th>
                        <th>Created At</th>
                        

                    </tr>
                    </thead>
                    <tbody>


                    <?php $__currentLoopData = $leads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lead): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><input type='checkbox' class="checkboxvar" name="checkboxvar[]" value="<?php echo e($lead->leadId); ?>"></td>
                            <td><?php echo e($lead->companyName); ?></td>
                            <td><?php echo e($lead->category->categoryName); ?></td>
                            <td><?php echo e($lead->website); ?></td>
                            <td><?php echo e($lead->email); ?></td>
                            <td><?php echo e($lead->country->countryName); ?></td>
                            <td><?php echo e($lead->comments); ?></td>
                            <td><?php echo e($lead->mined->firstName); ?></td>
                            <td><?php echo e($lead->created_at); ?></td>



                            
                                
                                    
                                    

                                

                                    
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>
                </table>
            </div>

            <input type="checkbox" id="selectall" onClick="selectAll(this)" /><b>Select All</b>
            <div class="form-group">


                
                <label ><b>Select Name:</b></label>
                <select class="form-control"  name="assignTo" id="otherCatches" style="width: 30%">
                    <option value="">select</option>
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($user->id); ?>"><?php echo e($user->firstName); ?> <?php echo e($user->lastName); ?></option>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                </select>
            </div>

            <input type="hidden" class="form-control" id="inp" name="leadId">


        </div>


        </div>
    </div>




<?php $__env->stopSection(); ?>

<?php $__env->startSection('foot-js'); ?>


    <script src="<?php echo e(asset('assets/plugins/datatables/jquery.dataTables.min.js')); ?>"></script>



    <script src="<?php echo e(asset('cdn.datatables.net/buttons/1.2.2/js/dataTables.buttons.min.js')); ?>"></script>
    <script src="<?php echo e(asset('cdn.datatables.net/buttons/1.2.2/js/buttons.flash.min.js')); ?>"></script>



    <script src="<?php echo e(asset('cdn.datatables.net/buttons/1.2.2/js/buttons.html5.min.js')); ?>"></script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-confirm/3.3.0/jquery-confirm.min.js"></script>


    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
    <script>

        var datatable;


        $(document).ready(function() {
             datatable= $('#myTable').DataTable(
                {
                    "order": [[ 7, "desc" ]]
                }
            );

        });

        function selectAll(source) {
            checkboxes = document.getElementsByName('checkboxvar[]');
            for(var i in checkboxes)
                checkboxes[i].checked = source.checked;
        }




        $("#otherCatches").change(function() {

            var chkArray = [];
            var userId=$(this).val();
            $('.checkboxvar:checked').each(function (i) {

                chkArray[i] = $(this).val();
            });
            var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');
            // $("#inp").val(JSON.stringify(chkArray));
            // $( "#assign-form" ).submit();
            jQuery('input:checkbox:checked').parents("tr").remove();
            $(this).prop('selectedIndex',0);

            $.ajax({
                type : 'post' ,
                url : '<?php echo e(route('assignStore')); ?>',
                data : {_token: CSRF_TOKEN,'leadId':chkArray,'userId':userId} ,
                success : function(data){
                    console.log(data);
                    if(data == 'true'){
                        $('#myTable').load(document.URL +  ' #myTable');
//                        $.alert({
//                            title: 'Success!',
//                            content: 'successfully assigned!',
//                        });
                        $('#alert').html(' <strong>Success!</strong> Assigned');
                        $('#alert').show();
                    }
                }
            });



        });






    </script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>