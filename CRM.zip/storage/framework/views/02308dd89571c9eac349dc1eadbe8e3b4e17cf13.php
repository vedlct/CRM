<div style="display:inline-block; margin:15px;">
  <?php
    $index = 0;
  ?>
  <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php
            $stringFormat =  strtolower(str_replace(' ', '', $item));
          ?>
		  
            <div class="input-group date">
                <div class="input-group-addon">
                    <i class="fa fa-calendar"></i>
                </div>
                <input type="text" value="<?php echo e(isset($oldVals) ? $oldVals[$index] : ''); ?>" name="<?=$stringFormat?>" id="<?=$stringFormat?>" placeholder="<?php echo e($item); ?>" required>
            
  <?php
    $index++;
  ?>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>