<?php $__env->startSection('content'); ?>

    <div class="card" style="padding:10px;">
        <div class="card-body">
            <h2 class="card-title" align="center"><b>Filtered Lead</b></h2>

            <div class="table-responsive m-t-40">
                <table id="myTable" class="table table-bordered table-striped">
                    <thead>
                    <tr>
                        <th>Company Name</th>
                        <th>Category</th>
                        <th>Country</th>
                        <th>Contact Person</th>
                        <th>Mined By</th>
                        <th>Contacted</th>
                    </tr>
                    </thead>
                    <tbody>

                    <?php $__currentLoopData = $leads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lead): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($lead->companyName); ?></td>
                            <td><?php echo e($lead->category->categoryName); ?></td>
                            <td><?php echo e($lead->country->countryName); ?></td>
                            <td><?php echo e($lead->personName); ?></td>
                            <td><?php echo e($lead->mined->firstName); ?></td>
                            <th>
                                <form method="post" action="<?php echo e(route('addContacted')); ?>">
                                    <?php echo e(@csrf_field()); ?>

                                    <input type="hidden" value="<?php echo e($lead->leadId); ?>" name="leadId">
                                    <button class="btn btn-info btn-sm"><i class="fa fa-bookmark" aria-hidden="true"></i></button>
                                </form>

                            </th>
                        </tr>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('foot-js'); ?>
    <script src="<?php echo e(asset('assets/plugins/datatables/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('cdn.datatables.net/buttons/1.2.2/js/dataTables.buttons.min.js')); ?>"></script>
    <script src="<?php echo e(asset('cdn.datatables.net/buttons/1.2.2/js/buttons.flash.min.js')); ?>"></script>
    <script src="<?php echo e(asset('cdn.datatables.net/buttons/1.2.2/js/buttons.html5.min.js')); ?>"></script>

    <script>
        $(document).ready(function() {
            $('#myTable').DataTable();

        });
    </script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>