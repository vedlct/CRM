<?php $__env->startSection('header'); ?>

    <link rel="stylesheet" href="https://jqueryvalidation.org/files/demo/site-demos.css">

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>


    <div class="card" style="width: 40%; padding: 10px; float: left;">
        <div class="row">
            <div class="col-md-3">
                <b>Name :</b>
            </div>

            <div class="col-md-9">
                <?php echo e($user->firstName); ?> <?php echo e($user->lastName); ?>

            </div>


            <div class="col-md-3">
                <b>Email :</b>
            </div>


            <div class="col-md-9">
                <?php echo e($user->userEmail); ?>

            </div>


            <div class="col-md-3">
                <b>Gender :</b>
            </div>


            <div class="col-md-9">
                <?php echo e($user->gender); ?>

            </div>
            <div class="col-md-3">
                <b>Date of Birth :</b>
            </div>
            <div class="col-md-9">
                <?php echo e($user->dob); ?>

            </div>


        </div>


    </div>




    <div class="card" style="max-width: 40%; padding: 10px; float: right; margin-right: 20%;">

        <h2 align="center"><b>Account Settings</b></h2><hr>

        <form action="<?php echo e(route('changePass')); ?>" method="post" id="myform">
            <?php echo e(@csrf_field()); ?>


            <div class="form-group">
                <label for="pwd">Current Password:</label>
                <input type="password" class="form-control" id="pwd" name="currentPassword">
                <div class="form-group<?php echo e($errors->has('currentPassword') ? ' has-error' : ''); ?> " >
                    <?php if($errors->has('currentPassword')): ?>
                        <span class="help-block">
                                        <strong><?php echo e($errors->first('currentPassword')); ?></strong>
                                    </span>
                    <?php endif; ?>
                </div>
            </div>

            <div class="form-group">
                <label for="pwd">New Password:</label>
                <input type="password" class="form-control" id="password" name="password">
                <div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?> " >
                    <?php if($errors->has('password')): ?>
                        <span class="help-block">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                    <?php endif; ?>
                </div>

            </div>

            <div class="form-group">
                <label for="pwd">Confirm New Password:</label>
                <input type="password" class="form-control" id="password_again" name="password_again">
            </div>

            <button type="submit" class="btn btn-primary" >Submit</button>
        </form>





    </div>




<?php $__env->stopSection(); ?>

<?php $__env->startSection('bottom'); ?>

    <script src="https://cdn.jsdelivr.net/jquery.validation/1.16.0/jquery.validate.min.js"></script>
    <script src="https://cdn.jsdelivr.net/jquery.validation/1.16.0/additional-methods.min.js"></script>
<script>



//    jQuery.validator.setDefaults({
//        debug: true,
//        success: "valid"
//    });
    var validator = $( "#myform" ).validate({
        rules: {
            password: "required",
            password_again: {
                equalTo: "#password"
            }

        }

    });




</script>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>