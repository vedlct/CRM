<?php $__env->startSection('content'); ?>
  <div class="box-body">
    <div class="card" style="padding: 2px;">
        <div class="card-body">
			<h2 style="display: inline-block; margin: 0px 200px;">List of countries</h2>
			<a class="btn btn-primary" href="<?php echo e(route('country.create')); ?>">Add new country</a>
            <div class="table-responsive m-t-40" >
            <table id="myTable" class="table table-striped table-condensed" style="font-size:14px;">
            <thead>
              <tr role="row">
                <th>Country Name</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td><?php echo e($country->countryName); ?></td>
                  <td>
                    <form method="POST" action="<?php echo e(route('country.destroy', ['id' => $country->countryId])); ?>" onsubmit = "return confirm('Are you sure?')">
                        <input type="hidden" name="_method" value="DELETE">
                        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                        <a href="<?php echo e(route('country.edit', ['id' => $country->countryId])); ?>" class="btn btn-info btn-sm">
							<i class="fa fa-pencil-square-o"></i>
                        </a>
                        <button type="submit" class="btn btn-danger btn-sm">
                          <i class="fa fa-trash"></i>
                        </button>
                    </form>
                  </td>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
        </div>
      </div>

		<?php $__env->startSection('foot-js'); ?>
			<script src="<?php echo e(asset('assets/plugins/datatables/jquery.dataTables.min.js')); ?>"></script>
			<script src="<?php echo e(asset('cdn.datatables.net/buttons/1.2.2/js/dataTables.buttons.min.js')); ?>"></script>
			<script src="<?php echo e(asset('cdn.datatables.net/buttons/1.2.2/js/buttons.flash.min.js')); ?>"></script>
			<script src="<?php echo e(asset('cdn.datatables.net/buttons/1.2.2/js/buttons.html5.min.js')); ?>"></script>

			<script>
				$(document).ready(function() {
					$('#myTable').DataTable();

				});
			</script>
		<?php $__env->stopSection(); ?>
    </div>
  </div>
  <!-- /.box-body -->
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>