<?php $__env->startSection('content'); ?>
    <div class="card" style="padding:10px;">
        <h2 align="center">Rejected Leads</h2>
        <div class="card-body">

            <table class="table table-bordered" id="posts">
                <thead>
                <th>Name</th>
                <th>Email</th>
                <th>Mined By</th>
                <th>Drop</th>

                </thead>
            </table>

        </div></div>


<?php $__env->stopSection(); ?>


<?php $__env->startSection('foot-js'); ?>




    <script src="<?php echo e(asset('assets/plugins/datatables/jquery.dataTables.min.js')); ?>"></script>

    <script src="<?php echo e(asset('cdn.datatables.net/buttons/1.2.2/js/dataTables.buttons.min.js')); ?>"></script>
    <script src="<?php echo e(asset('cdn.datatables.net/buttons/1.2.2/js/buttons.flash.min.js')); ?>"></script>


    <script src="<?php echo e(asset('cdn.datatables.net/buttons/1.2.2/js/buttons.html5.min.js')); ?>"></script>


    <script>
        $(document).ready(function () {
            $('#posts').DataTable({
                "processing": true,
                "serverSide": true,
                "ajax":{
                    "url": "<?php echo e(route('rejectData')); ?>",
                    "dataType": "json",
                    "type": "POST",
                    "data":{ _token: "<?php echo e(csrf_token()); ?>"}
                },
                "columns": [
                    { "data": "name" },
                    { "data": "email" },
                    { "data": "minedBy" },
                    { "data": "drop" }
                ]

            });
        });
    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>