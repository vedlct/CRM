<div class="box box-default">
  <!-- /.box-header -->
    {{ $slot }} 
    <button type="submit" class="btn btn-primary" style="margin-left:15px;">
      Search
    </button>
</div>
</div>