@extends('main')



@section('content')



    I am inside content




    @endsection