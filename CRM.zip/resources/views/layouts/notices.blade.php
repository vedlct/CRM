@extends('main')

@section('content')

    <div style="background-color:#ECF0F1; padding: 10px; border-radius: 5px;">
<div class="row">
    <div class="col-md-3">

        <div class="card">
            <div class="card-header">Header</div>
            <div class="card-body">Content</div>
            <div class="card-footer">Footer</div>
        </div>

    </div>


    <div class="col-md-3">

        <div class="card">
            <div class="card-header">Header</div>
            <div class="card-body">Content</div>
            <div class="card-footer">Footer</div>
        </div>

    </div>

    <div class="col-md-3">

        <div class="card">
            <div class="card-header">Header</div>
            <div class="card-body">Content</div>
            <div class="card-footer">Footer</div>
        </div>

    </div>


    <div class="col-md-3">

        <div class="card">
            <div class="card-header">Header</div>
            <div class="card-body">Content</div>
            <div class="card-footer">Footer</div>
        </div>

    </div>



    <div class="col-md-3">

        <div class="card">
            <div class="card-header">Header</div>
            <div class="card-body">Content</div>
            <div class="card-footer">Footer</div>
        </div>

    </div>





    <div class="col-md-3">

        <div class="card">
            <div class="card-header">Header</div>
            <div class="card-body">Content</div>
            <div class="card-footer">Footer</div>
        </div>

    </div>





</div>


    </div>

@endsection