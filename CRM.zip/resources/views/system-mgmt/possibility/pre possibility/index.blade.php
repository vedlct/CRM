@extends('main')

@section('content')
  <div class="box-body">
    <div class="card" style="max-width: 45%;">
        <div class="card-body">
			<h2 align="center">List of possibility</h2>
			<a class="btn btn-primary" href="{{ route('possibility.create') }}">Add new possibility</a>
            <div class="table-responsive m-t-40" >
            <table id="myTable" class="table table-striped table-condensed" style="font-size:14px;">
            <thead>
              <tr>
                <th>Possibility Name</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
            @foreach ($possibilities as $possibility)
                <tr>
                  <td>{{ $possibility->possibilityName }}</td>
                  <td>
                    <form method="POST" action="{{ route('possibility.destroy', ['id' => $possibility->possibilityId]) }}" onsubmit = "return confirm('Are you sure?')">
                        <input type="hidden" name="_method" value="DELETE">
                        <input type="hidden" name="_token" value="{{ csrf_token() }}">
                        <a href="{{ route('possibility.edit', ['id' => $possibility->possibilityId]) }}" class="btn btn-info btn-sm">
							<i class="fa fa-pencil-square-o"></i>
                        </a>
                        <button type="submit" class="btn btn-danger btn-sm">
                          <i class="fa fa-trash"></i>
                        </button>
                    </form>
                  </td>
              </tr>
            @endforeach
            </tbody>
          </table>
        </div>
      </div>

		@section('foot-js')
			<script src="{{asset('assets/plugins/datatables/jquery.dataTables.min.js')}}"></script>
			<script src="{{asset('cdn.datatables.net/buttons/1.2.2/js/dataTables.buttons.min.js')}}"></script>
			<script src="{{asset('cdn.datatables.net/buttons/1.2.2/js/buttons.flash.min.js')}}"></script>
			<script src="{{asset('cdn.datatables.net/buttons/1.2.2/js/buttons.html5.min.js')}}"></script>

			<script>
				$(document).ready(function() {
					$('#myTable').DataTable();

				});
			</script>
		@endsection
    </div>
  </div>
  <!-- /.box-body -->
</div>
@endsection