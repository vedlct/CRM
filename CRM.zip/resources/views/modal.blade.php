
<form>
    <div class="form-group">
        <label for="recipient-name" class="control-label">Recipient:</label>
        <input type="text" class="form-control" id="recipient-name" value="{{$v}}">
    </div>
    <div class="form-group">
        <label for="message-text" class="control-label">Message:</label>
        <textarea class="form-control" id="message-text"></textarea>
    </div></form>
